package Ae2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Clase Cliente que representa el cliente en una aplicación de chat.
 */
public class Cliente {

    /** Dirección IP del servidor al que se conectará el cliente. */
    private static final String SERVIDOR_IP = "localhost";

    /** Puerto en el que se conectará el cliente. */
    private static final int PUERTO = 5000;

    /**
     * Método principal que inicia la aplicación del cliente.
     * @param args Argumentos de la línea de comandos (no se utilizan).
     */
    public static void main(String[] args) {
        try {
            // Establecer conexión con el servidor
            Socket socket = new Socket(SERVIDOR_IP, PUERTO);

            // Configurar lectura y escritura de datos
            BufferedReader inputReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter outputWriter = new PrintWriter(socket.getOutputStream(), true);

            // Hilo para recibir mensajes del servidor
            Thread receiveThread = new Thread(() -> {
                try {
                    while (true) {
                        String receivedMessage = inputReader.readLine();
                        if (receivedMessage == null) {
                            break;
                        }
                        displayMessage(receivedMessage);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
            receiveThread.start();

            // Hilo para enviar mensajes al servidor
            Thread sendThread = new Thread(() -> {
                try {
                    BufferedReader consoleReader = new BufferedReader(new InputStreamReader(System.in));
                    while (true) {
                        String messageToSend = consoleReader.readLine();
                        if (messageToSend.equals("exit")) {
                            outputWriter.println(messageToSend);
                            break;
                        }
                        outputWriter.println(messageToSend);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
            sendThread.start();

            // Esperar a que ambos hilos terminen
            receiveThread.join();
            sendThread.join();

            // Cerrar el socket al finalizar
            socket.close();
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * Método para mostrar un mensaje en la consola con TimeStamp.
     * @param message Mensaje a mostrar en la consola.
     */
    private static void displayMessage(String message) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
        String timeStamp = dateFormat.format(new Date());
        System.out.println(timeStamp + " " + message);
    }
}
