package Ae2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

/**
 * Clase que representa el servidor de chat.
 */
public class Servidor {

    /** Puerto en el que escucha el servidor. */
    private static final int PUERTO = 5000;

    /** Lista de controladores de clientes conectados al servidor. */
    private static ArrayList<ClientHandler> clients = new ArrayList<>();

    /**
     * Método principal que inicia el servidor y acepta conexiones de clientes.
     * @param args Argumentos de la línea de comandos (no se utilizan).
     */
    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(PUERTO);
            System.out.println("Servidor a la espera de conexiones en el puerto " + PUERTO + "...");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Nuevo cliente conectado: " + clientSocket);

                ClientHandler clientHandler = new ClientHandler(clientSocket, clients);
                synchronized (clients) {
                    clients.add(clientHandler);
                }

                Thread thread = new Thread(clientHandler);
                thread.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Método para transmitir mensajes a todos los clientes conectados, excepto al remitente.
     * @param message Mensaje a transmitir.
     * @param sender Cliente que envía el mensaje.
     */
    public static synchronized void broadcastMessage(String message, ClientHandler sender) {
        synchronized (clients) {
            for (ClientHandler client : clients) {
                if (client != sender) {
                    client.sendMessage(sender.getUsername() + ": " + message);
                }
            }
        }
    }

    /**
     * Método para enviar un mensaje privado a un usuario específico.
     * @param message Mensaje a enviar.
     * @param recipientUsername Nombre de usuario del destinatario.
     */
    public static synchronized void sendPrivateMessage(String message, String recipientUsername) {
        synchronized (clients) {
            for (ClientHandler client : clients) {
                if (client.getUsername().equals(recipientUsername)) {
                    client.sendMessage(message);
                    return;
                }
            }
        }
    }

    /**
     * Método para obtener la lista de usuarios conectados.
     * @return Lista de usuarios conectados.
     */
    public static synchronized ArrayList<String> getUserList() {
        synchronized (clients) {
            ArrayList<String> userList = new ArrayList<>();
            for (ClientHandler client : clients) {
                userList.add(client.getUsername());
            }
            return userList;
        }
    }

    /**
     * Método para quitar un cliente de la lista al desconectarse.
     * @param clientHandler Cliente a ser removido.
     */
    public static synchronized void removeClient(ClientHandler clientHandler) {
        synchronized (clients) {
            clients.remove(clientHandler);
        }
    }
}
